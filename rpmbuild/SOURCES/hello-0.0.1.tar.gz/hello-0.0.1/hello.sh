#!/bin/sh
echo "Satellite is great."
